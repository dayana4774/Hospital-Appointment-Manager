jQuery(document).ready(function($) {
    const form = $('#ha-appointment-form');
    const doctorSelect = $('#doctor_id');
    const dateInput = $('#appointment_date');
    const timeSelect = $('#appointment_time');
    
    // Update available dates when doctor is selected
    doctorSelect.on('change', function() {
        const selectedOption = $(this).find('option:selected');
        const availableDays = selectedOption.data('days').split(',');
        
        // Reset date and time inputs
        dateInput.val('');
        updateTimeSlots([]);
        
        // Set min date to today
        const today = new Date().toISOString().split('T')[0];
        dateInput.attr('min', today);
        
        // Disable dates that aren't available for selected doctor
        dateInput.on('input', function() {
            const selected = new Date(this.value);
            const day = selected.toLocaleDateString('en-US', { weekday: 'long' });
            
            if (!availableDays.includes(day)) {
                this.value = '';
                alert('This doctor is not available on ' + day + 's');
            } else {
                updateTimeSlots(selectedOption.data('slots').split('\n'));
            }
        });
    });
    
    function updateTimeSlots(slots) {
        timeSelect.empty();
        timeSelect.append($('<option>', {
            value: '',
            text: 'Select time slot'
        }));
        
        slots.forEach(slot => {
            timeSelect.append($('<option>', {
                value: slot.trim(),
                text: slot.trim()
            }));
        });
    }
    
    // Form submission
    form.on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        formData.append('action', 'ha_book_appointment');
        formData.append('nonce', haAjax.nonce);
        
        $.ajax({
            url: haAjax.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                const messageDiv = form.find('.ha-form-message');
                
                if (response.success) {
                    messageDiv.removeClass('error').addClass('success');
                    form.trigger('reset');
                } else {
                    messageDiv.removeClass('success').addClass('error');
                }
                
                messageDiv.html(response.data).show();
            }
        });
    });
});
jQuery(document).ready(function($) {
    const form = $('#ha-appointment-form');
    const messageDiv = $('.ha-form-message');

    form.on('submit', function(e) {
        e.preventDefault();
        
        // Clear previous messages
        messageDiv.removeClass('success error').empty();
        
        // Show loading state
        const submitButton = form.find('.ha-submit-btn');
        submitButton.prop('disabled', true).text('Processing...');
        
        const formData = new FormData(this);
        formData.append('action', 'ha_book_appointment');
        formData.append('nonce', $('#ha_appointment_nonce').val());

        $.ajax({
            url: haAjax.ajaxurl, // Changed from ajaxurl to haAjax.ajaxurl
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                console.log('Response:', response); // For debugging
                
                if (response.success) {
                    // Show success message
                    messageDiv.addClass('success')
                             .html('<p>' + response.data + '</p>')
                             .fadeIn();
                    
                    // Reset form
                    form[0].reset();
                    $('#appointment_time').html('<option value="">Select date first</option>');
                    
                    // Scroll to message
                    $('html, body').animate({
                        scrollTop: messageDiv.offset().top - 100
                    }, 500);
                } else {
                    // Show error message
                    messageDiv.addClass('error')
                             .html('<p>' + (response.data || 'An error occurred. Please try again.') + '</p>')
                             .fadeIn();
                }
            },
            error: function(xhr, status, error) {
                console.log('AJAX Error:', error); // For debugging
                // Show general error message
                messageDiv.addClass('error')
                         .html('<p>An error occurred. Please try again later.</p>')
                         .fadeIn();
            },
            complete: function() {
                // Reset button state
                submitButton.prop('disabled', false).text('Book Appointment');
            }
        });
    });
});




