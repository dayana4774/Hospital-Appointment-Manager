jQuery(document).ready(function($) {
    const form = $('#ha-appointment-form');
    const doctorSelect = $('#doctor_id');
    const dateInput = $('#appointment_date');
    const timeSelect = $('#appointment_time');
    
    // Update available dates when doctor is selected
    doctorSelect.on('change', function() {
        const selectedOption = $(this).find('option:selected');
        const availableDays = selectedOption.data('days').split(',');
        
        // Reset date and time inputs
        dateInput.val('');
        updateTimeSlots([]);
        
        // Set min date to today
        const today = new Date().toISOString().split('T')[0];
        dateInput.attr('min', today);
        
        // Disable dates that aren't available for selected doctor
        dateInput.on('input', function() {
            const selected = new Date(this.value);
            const day = selected.toLocaleDateString('en-US', { weekday: 'long' });
            
            if (!availableDays.includes(day)) {
                this.value = '';
                alert('This doctor is not available on ' + day + 's');
            } else {
                updateTimeSlots(selectedOption.data('slots').split('\n'));
            }
        });
    });
    
    function updateTimeSlots(slots) {
        timeSelect.empty();
        timeSelect.append($('<option>', {
            value: '',
            text: 'Select time slot'
        }));
        
        slots.forEach(slot => {
            timeSelect.append($('<option>', {
                value: slot.trim(),
                text: slot.trim()
            }));
        });
    }
    
    // Form submission
    form.on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        formData.append('action', 'ha_book_appointment');
        formData.append('nonce', haAjax.nonce);
        
        $.ajax({
            url: haAjax.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                const messageDiv = form.find('.ha-form-message');
                
                if (response.success) {
                    messageDiv.removeClass('error').addClass('success');
                    form.trigger('reset');
                } else {
                    messageDiv.removeClass('success').addClass('error');
                }
                
                messageDiv.html(response.data).show();
            }
        });
    });
});