jQuery(document).ready(function($) {
    // Status update handling
    $('.ha-status-select').on('change', function() {
        const select = $(this);
        const appointmentId = select.data('id');
        const newStatus = select.val();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ha_update_appointment_status',
                appointment_id: appointmentId,
                status: newStatus,
                nonce: haAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    select.css('background-color', '#dff0d8');
                    setTimeout(() => select.css('background-color', ''), 1000);
                }
            }
        });
    });
    
    // Delete appointment handling
    $('.ha-delete-appointment').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this appointment?')) {
            return;
        }
        
        const link = $(this);
        const appointmentId = link.data('id');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ha_delete_appointment',
                appointment_id: appointmentId,
                nonce: haAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    link.closest('tr').fadeOut();
                }
            }
        });
    });
    
    // Doctor deletion handling
    $('.ha-delete-doctor').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this doctor?')) {
            return;
        }
        
        const link = $(this);
        const doctorId = link.data('id');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ha_delete_doctor',
                doctor_id: doctorId,
                nonce: haAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    link.closest('tr').fadeOut();
                }
            }
        });
    });
});