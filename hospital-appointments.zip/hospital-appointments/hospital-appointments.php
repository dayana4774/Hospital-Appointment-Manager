<?php
/**
 * Plugin Name: Hospital Appointments
 * Description: A plugin to manage hospital appointments and doctor schedules
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: hospital-appointments
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('HA_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('HA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('HA_VERSION', '1.0.0');

// Function to check if all required files exist
function ha_check_required_files() {
    $required_files = array(
        'includes/class-email-notifications.php',
        'includes/admin/admin-menu.php',
        'includes/admin/doctors-manager.php',
        'includes/admin/appointments-manager.php',
        'includes/frontend/shortcodes.php'
    );
    
    foreach ($required_files as $file) {
        if (!file_exists(HA_PLUGIN_PATH . $file)) {
            return false;
        }
    }
    return true;
}

// Check required files before proceeding
if (!ha_check_required_files()) {
    add_action('admin_notices', function() {
        ?>
        <div class="error">
            <p><?php _e('Hospital Appointments Plugin Error: Missing required files. Please ensure all plugin files are properly installed.', 'hospital-appointments'); ?></p>
        </div>
        <?php
    });
    return;
}

// Include files only if they exist
try {
    require_once HA_PLUGIN_PATH . 'includes/class-email-notifications.php';
    require_once HA_PLUGIN_PATH . 'includes/admin/admin-menu.php';
    require_once HA_PLUGIN_PATH . 'includes/admin/doctors-manager.php';
    require_once HA_PLUGIN_PATH . 'includes/admin/appointments-manager.php';
    require_once HA_PLUGIN_PATH . 'includes/frontend/shortcodes.php';
} catch (Exception $e) {
    add_action('admin_notices', function() use ($e) {
        ?>
        <div class="error">
            <p><?php echo esc_html('Hospital Appointments Plugin Error: ' . $e->getMessage()); ?></p>
        </div>
        <?php
    });
    return;
}

// Plugin activation
register_activation_hook(__FILE__, 'ha_activate_plugin');

function ha_activate_plugin() {
    try {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create doctors table
        $doctors_table = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ha_doctors (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            specialty varchar(100) NOT NULL,
            available_days text NOT NULL,
            time_slots text NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Create appointments table
        $appointments_table = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ha_appointments (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            patient_name varchar(100) NOT NULL,
            patient_email varchar(100) NOT NULL,
            doctor_id mediumint(9) NOT NULL,
            appointment_date date NOT NULL,
            appointment_time time NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($doctors_table);
        dbDelta($appointments_table);
        
    } catch (Exception $e) {
        wp_die('Error activating plugin: ' . $e->getMessage());
    }
}

// Initialize plugin
function ha_init_plugin() {
    if (!function_exists('ha_create_admin_menu')) {
        return;
    }
    
    // Initialize admin menus
    add_action('admin_menu', 'ha_create_admin_menu');
    
    // Register shortcode
    add_shortcode('hospital_appointment_form', 'ha_appointment_form_shortcode');
    
    // Enqueue scripts and styles
    add_action('admin_enqueue_scripts', 'ha_admin_scripts');
    add_action('wp_enqueue_scripts', 'ha_frontend_scripts');
}
add_action('plugins_loaded', 'ha_init_plugin');

// Admin scripts and styles
function ha_admin_scripts($hook) {
    if (strpos($hook, 'hospital-appointments') !== false) {
        wp_enqueue_style('ha-admin-style', HA_PLUGIN_URL . 'assets/css/admin.css', array(), HA_VERSION);
        wp_enqueue_script('ha-admin-script', HA_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), HA_VERSION, true);
        
        wp_localize_script('ha-admin-script', 'haAjax', array(
            'nonce' => wp_create_nonce('ha_admin_nonce')
        ));
    }
}


// Frontend scripts and styles
function ha_frontend_scripts() {
    wp_enqueue_style('ha-frontend-style', HA_PLUGIN_URL . 'assets/css/frontend.css', array(), HA_VERSION);
    wp_enqueue_script('ha-frontend-script', HA_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), HA_VERSION, true);
    
    wp_localize_script('ha-frontend-script', 'haAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ha_frontend_nonce')
    ));
}