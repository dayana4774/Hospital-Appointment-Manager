<?php
/**
 * Plugin Name: Hospital Appointments
 * Description: A plugin to manage hospital appointments and doctor schedules
 * Version: 1.0.0
 * Author: Dayana babu
 * Text Domain: hospital-appointments
 */

// Enable error reporting for debugging
if (!defined('WP_DEBUG')) {
    define('WP_DEBUG', true);
}
if (!defined('WP_DEBUG_LOG')) {
    define('WP_DEBUG_LOG', true);
}
if (!defined('WP_DEBUG_DISPLAY')) {
    define('WP_DEBUG_DISPLAY', true);
}
@ini_set('display_errors', 1);

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('HA_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('HA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('HA_VERSION', '1.0.0');

// Simple error logging function
function ha_log($message) {
    if (WP_DEBUG === true) {
        if (is_array($message) || is_object($message)) {
            error_log(print_r($message, true));
        } else {
            error_log($message);
        }
    }
}

// Check if required files exist before including them
$required_files = array(
    'includes/class-email-notifications.php',
    'includes/admin/admin-menu.php',
    'includes/admin/doctors-manager.php',
    'includes/admin/appointments-manager.php',
    'includes/frontend/shortcodes.php'
);

$missing_files = array();
foreach ($required_files as $file) {
    if (!file_exists(HA_PLUGIN_PATH . $file)) {
        $missing_files[] = $file;
    }
}

if (!empty($missing_files)) {
    ha_log('Missing required files: ' . print_r($missing_files, true));
    return;
}

// Include required files
require_once HA_PLUGIN_PATH . 'includes/class-email-notifications.php';
require_once HA_PLUGIN_PATH . 'includes/admin/admin-menu.php';
require_once HA_PLUGIN_PATH . 'includes/admin/doctors-manager.php';
require_once HA_PLUGIN_PATH . 'includes/admin/appointments-manager.php';
require_once HA_PLUGIN_PATH . 'includes/frontend/shortcodes.php';

// Plugin activation
register_activation_hook(__FILE__, 'ha_activate_plugin');

function ha_activate_plugin() {
    try {
        global $wpdb;
        
        ha_log('Starting plugin activation...');
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create doctors table
        $doctors_table = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ha_doctors (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            specialty varchar(100) NOT NULL,
            available_days text NOT NULL,
            time_slots text NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        // Create appointments table
        $appointments_table = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ha_appointments (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            patient_name varchar(100) NOT NULL,
            patient_email varchar(100) NOT NULL,
            doctor_id mediumint(9) NOT NULL,
            appointment_date date NOT NULL,
            appointment_time time NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($doctors_table);
        $doctors_table_error = $wpdb->last_error;
        if (!empty($doctors_table_error)) {
            ha_log('Error creating doctors table: ' . $doctors_table_error);
        }
        
        dbDelta($appointments_table);
        $appointments_table_error = $wpdb->last_error;
        if (!empty($appointments_table_error)) {
            ha_log('Error creating appointments table: ' . $appointments_table_error);
        }
        
        ha_log('Plugin activation completed successfully');
        
    } catch (Exception $e) {
        ha_log('Error during plugin activation: ' . $e->getMessage());
    }
}

// Initialize plugin
add_action('plugins_loaded', 'ha_init_plugin');

function ha_init_plugin() {
    try {
        // Initialize admin menus
        add_action('admin_menu', 'ha_create_admin_menu');
        
        // Register shortcode
        add_shortcode('hospital_appointment_form', 'ha_appointment_form_shortcode');
        
        // Enqueue scripts and styles
        add_action('admin_enqueue_scripts', 'ha_admin_scripts');
        add_action('wp_enqueue_scripts', 'ha_frontend_scripts');
        
        ha_log('Plugin initialized successfully');
        
    } catch (Exception $e) {
        ha_log('Error during plugin initialization: ' . $e->getMessage());
    }
}

// Admin scripts and styles
function ha_admin_scripts($hook) {
    if (strpos($hook, 'hospital-appointments') !== false) {
        wp_enqueue_style('ha-admin-style', HA_PLUGIN_URL . 'assets/css/admin.css', array(), HA_VERSION);
        wp_enqueue_script('ha-admin-script', HA_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), HA_VERSION, true);
        
        wp_localize_script('ha-admin-script', 'haAjax', array(
            'nonce' => wp_create_nonce('ha_admin_nonce')
        ));
    }
}

// Frontend scripts and styles
function ha_frontend_scripts() {
    wp_enqueue_style('ha-frontend-style', HA_PLUGIN_URL . 'assets/css/frontend.css', array(), HA_VERSION);
    wp_enqueue_script('ha-frontend-script', HA_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), HA_VERSION, true);
    
    wp_localize_script('ha-frontend-script', 'haAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ha_frontend_nonce')
    ));
}

// Helper functions
function ha_send_confirmation_email($appointment_id) {
    return HA_Email_Notifications::send_confirmation_email($appointment_id);
}

function ha_send_status_update_email($appointment_id, $status) {
    return HA_Email_Notifications::send_status_update_email($appointment_id, $status);
}