<?php
if (!defined('ABSPATH')) {
    exit;
}

function ha_create_admin_menu() {
    add_menu_page(
        __('Hospital Appointments', 'hospital-appointments'),
        __('Hospital Appointments', 'hospital-appointments'),
        'manage_options',
        'hospital-appointments',
        'ha_appointments_page',
        'dashicons-calendar-alt',
        30
    );
    
    add_submenu_page(
        'hospital-appointments',
        __('Doctors', 'hospital-appointments'),
        __('Doctors', 'hospital-appointments'),
        'manage_options',
        'ha-doctors',
        'ha_doctors_page'
    );
}