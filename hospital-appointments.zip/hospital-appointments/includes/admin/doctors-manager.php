<?php
if (!defined('ABSPATH')) {
    exit;
}

function ha_doctors_page() {
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'list';
    
    switch ($action) {
        case 'add':
        case 'edit':
            ha_doctor_form();
            break;
        default:
            ha_doctors_list();
            break;
    }
}

function ha_doctors_list() {
    global $wpdb;
    $doctors = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ha_doctors ORDER BY name ASC");
    ?>
    <div class="wrap">
        <h1><?php _e('Doctors', 'hospital-appointments'); ?>
            <a href="?page=ha-doctors&action=add" class="page-title-action"><?php _e('Add New', 'hospital-appointments'); ?></a>
        </h1>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('Name', 'hospital-appointments'); ?></th>
                    <th><?php _e('Specialty', 'hospital-appointments'); ?></th>
                    <th><?php _e('Available Days', 'hospital-appointments'); ?></th>
                    <th><?php _e('Time Slots', 'hospital-appointments'); ?></th>
                    <th><?php _e('Actions', 'hospital-appointments'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($doctors as $doctor): ?>
                    <tr>
                        <td><?php echo esc_html($doctor->name); ?></td>
                        <td><?php echo esc_html($doctor->specialty); ?></td>
                        <td><?php echo esc_html($doctor->available_days); ?></td>
                        <td><?php echo esc_html($doctor->time_slots); ?></td>
                        <td>
                            <a href="?page=ha-doctors&action=edit&id=<?php echo $doctor->id; ?>"><?php _e('Edit', 'hospital-appointments'); ?></a> |
                            <a href="#" class="ha-delete-doctor" data-id="<?php echo $doctor->id; ?>"><?php _e('Delete', 'hospital-appointments'); ?></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

function ha_doctor_form() {
    global $wpdb;
    $doctor_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $doctor = new stdClass();
    
    if ($doctor_id) {
        $doctor = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ha_doctors WHERE id = %d", $doctor_id));
    }
    
    ?>
    <div class="wrap">
        <h1><?php echo $doctor_id ? __('Edit Doctor', 'hospital-appointments') : __('Add New Doctor', 'hospital-appointments'); ?></h1>
        
        <form method="post" action="" class="ha-doctor-form">
            <?php wp_nonce_field('ha_save_doctor', 'ha_doctor_nonce'); ?>
            <input type="hidden" name="doctor_id" value="<?php echo $doctor_id; ?>">
            
            <table class="form-table">
                <tr>
                    <th><label for="name"><?php _e('Name', 'hospital-appointments'); ?></label></th>
                    <td>
                        <input type="text" name="name" id="name" class="regular-text" 
                               value="<?php echo isset($doctor->name) ? esc_attr($doctor->name) : ''; ?>" required>
                    </td>
                </tr>
                <tr>
                    <th><label for="specialty"><?php _e('Specialty', 'hospital-appointments'); ?></label></th>
                    <td>
                        <input type="text" name="specialty" id="specialty" class="regular-text" 
                               value="<?php echo isset($doctor->specialty) ? esc_attr($doctor->specialty) : ''; ?>" required>
                    </td>
                </tr>
                <tr>
                    <th><label><?php _e('Available Days', 'hospital-appointments'); ?></label></th>
                    <td>
                        <?php
                        $days = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
                        $selected_days = isset($doctor->available_days) ? explode(',', $doctor->available_days) : array();
                        foreach ($days as $day) {
                            ?>
                            <label>
                                <input type="checkbox" name="available_days[]" value="<?php echo $day; ?>"
                                    <?php echo in_array($day, $selected_days) ? 'checked' : ''; ?>>
                                <?php echo $day; ?>
                            </label><br>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <th><label for="time_slots"><?php _e('Time Slots', 'hospital-appointments'); ?></label></th>
                    <td>
                        <textarea name="time_slots" id="time_slots" rows="5" class="large-text"><?php 
                            echo isset($doctor->time_slots) ? esc_textarea($doctor->time_slots) : ''; 
                        ?></textarea>
                        <p class="description"><?php _e('Enter time slots one per line (e.g., 10:00 AM - 11:00 AM)', 'hospital-appointments'); ?></p>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <input type="submit" name="submit" id="submit" class="button button-primary" 
                       value="<?php echo $doctor_id ? __('Update Doctor', 'hospital-appointments') : __('Add Doctor', 'hospital-appointments'); ?>">
            </p>
        </form>
    </div>
    <?php
}

// AJAX handlers for doctor operations
add_action('wp_ajax_ha_save_doctor', 'ha_ajax_save_doctor');
add_action('wp_ajax_ha_delete_doctor', 'ha_ajax_delete_doctor');

function ha_ajax_save_doctor() {
    check_ajax_referer('ha_save_doctor', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions', 'hospital-appointments'));
    }
    
    global $wpdb;
    
    $doctor_id = isset($_POST['doctor_id']) ? intval($_POST['doctor_id']) : 0;
    $name = sanitize_text_field($_POST['name']);
    $specialty = sanitize_text_field($_POST['specialty']);
    $available_days = isset($_POST['available_days']) ? implode(',', array_map('sanitize_text_field', $_POST['available_days'])) : '';
    $time_slots = sanitize_textarea_field($_POST['time_slots']);
    
    $data = array(
        'name' => $name,
        'specialty' => $specialty,
        'available_days' => $available_days,
        'time_slots' => $time_slots
    );
    
    if ($doctor_id) {
        $wpdb->update(
            "{$wpdb->prefix}ha_doctors",
            $data,
            array('id' => $doctor_id)
        );
    } else {
        $wpdb->insert(
            "{$wpdb->prefix}ha_doctors",
            $data
        );
    }
    
    wp_send_json_success();
}

function ha_ajax_delete_doctor() {
    check_ajax_referer('ha_delete_doctor', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions', 'hospital-appointments'));
    }
    
    global $wpdb;
    $doctor_id = isset($_POST['doctor_id']) ? intval($_POST['doctor_id']) : 0;
    
    if ($doctor_id) {
        $wpdb->delete(
            "{$wpdb->prefix}ha_doctors",
            array('id' => $doctor_id)
        );
    }
    
    wp_send_json_success();
}