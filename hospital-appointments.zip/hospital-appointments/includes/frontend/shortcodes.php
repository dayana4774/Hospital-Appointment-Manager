<script type="text/javascript">
    var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
</script>
<?php
if (!defined('ABSPATH')) {
    exit;
}











function ha_appointment_form_shortcode($atts) {
    ob_start();
    
    global $wpdb;
    $doctors = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ha_doctors ORDER BY name ASC");
    
    ?>
    <div class="ha-appointment-form-wrapper">
        <form id="ha-appointment-form" class="ha-appointment-form">
            <?php wp_nonce_field('ha_book_appointment', 'ha_appointment_nonce'); ?>
            
            <div class="ha-form-row">
                <label for="patient_name"><?php _e('Your Name', 'hospital-appointments'); ?></label>
                <input type="text" id="patient_name" name="patient_name" required>
            </div>
            
            <div class="ha-form-row">
                <label for="patient_email"><?php _e('Your Email', 'hospital-appointments'); ?></label>
                <input type="email" id="patient_email" name="patient_email" required>
            </div>
            
            <div class="ha-form-row">
                <label for="doctor_id"><?php _e('Select Doctor', 'hospital-appointments'); ?></label>
                <select id="doctor_id" name="doctor_id" required>
                    <option value=""><?php _e('Choose a doctor', 'hospital-appointments'); ?></option>
                    <?php foreach ($doctors as $doctor): ?>
                        <option value="<?php echo $doctor->id; ?>" 
                                data-days="<?php echo esc_attr($doctor->available_days); ?>"
                                data-slots="<?php echo esc_attr($doctor->time_slots); ?>">
                            <?php echo esc_html($doctor->name); ?> (<?php echo esc_html($doctor->specialty); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="ha-form-row">
                <label for="appointment_date"><?php _e('Appointment Date', 'hospital-appointments'); ?></label>
                <input type="date" id="appointment_date" name="appointment_date" required>
            </div>
            
            <div class="ha-form-row">
                <label for="appointment_time"><?php _e('Appointment Time', 'hospital-appointments'); ?></label>
                <select id="appointment_time" name="appointment_time" required>
                    <option value=""><?php _e('Select date first', 'hospital-appointments'); ?></option>
                </select>
            </div>
            
            <div class="ha-form-row">
                <button type="submit" class="ha-submit-btn">
                    <?php _e('Book Appointment', 'hospital-appointments'); ?>
                </button>
            </div>
            
            <div class="ha-form-message"></div>
        </form>
    </div>
    <?php
    
    return ob_get_clean();
}

// AJAX handler for booking appointments
add_action('wp_ajax_ha_book_appointment', 'ha_ajax_book_appointment');
add_action('wp_ajax_nopriv_ha_book_appointment', 'ha_ajax_book_appointment');

function ha_ajax_book_appointment() {
    check_ajax_referer('ha_book_appointment', 'nonce');
    
    $patient_name = sanitize_text_field($_POST['patient_name']);
    $patient_email = sanitize_email($_POST['patient_email']);
    $doctor_id = intval($_POST['doctor_id']);
    $appointment_date = sanitize_text_field($_POST['appointment_date']);
    $appointment_time = sanitize_text_field($_POST['appointment_time']);
    
    // Validate inputs
    if (empty($patient_name) || empty($patient_email) || empty($doctor_id) || 
        empty($appointment_date) || empty($appointment_time)) {
        wp_send_json_error(__('All fields are required.', 'hospital-appointments'));
    }
    
    // Check for duplicate appointments
    global $wpdb;
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}ha_appointments 
         WHERE doctor_id = %d 
         AND appointment_date = %s 
         AND appointment_time = %s 
         AND status != 'cancelled'",
        $doctor_id,
        $appointment_date,
        $appointment_time
    ));
    
    if ($existing > 0) {
        wp_send_json_error(__('This time slot is already booked. Please choose another.', 'hospital-appointments'));
    }
    
    // Insert appointment
    $result = $wpdb->insert(
        "{$wpdb->prefix}ha_appointments",
        array(
            'patient_name' => $patient_name,
            'patient_email' => $patient_email,
            'doctor_id' => $doctor_id,
            'appointment_date' => $appointment_date,
            'appointment_time' => $appointment_time,
            'status' => 'pending'
        )
    );
    
    if ($result) {
        // Send confirmation email
        ha_send_confirmation_email($wpdb->insert_id);
        
        wp_send_json_success(__('Appointment booked successfully! Check your email for confirmation.', 'hospital-appointments'));
    } else {
        wp_send_json_error(__('Failed to book appointment. Please try again.', 'hospital-appointments'));
    }
}