<?php
if (!defined('ABSPATH')) {
    exit;
}

// Add main menu and submenus
function ha_create_admin_menu() {
    add_menu_page(
        'Hospital Appointments',
        'Hospital Appointments',
        'manage_options',
        'hospital-appointments',
        'ha_appointments_page',
        'dashicons-calendar-alt',
        30
    );

    add_submenu_page(
        'hospital-appointments',
        'View Appointments',
        'View Appointments',
        'manage_options',
        'hospital-appointments',
        'ha_appointments_page'
    );

    add_submenu_page(
        'hospital-appointments',
        'Manage Doctors',
        'manage_options',
        'ha-doctors',
        'ha_doctors_page'
    );
}
add_action('admin_menu', 'ha_create_admin_menu');