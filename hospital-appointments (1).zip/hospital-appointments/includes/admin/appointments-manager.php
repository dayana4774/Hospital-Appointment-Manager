<?php
if (!defined('ABSPATH')) {
    exit;
}

function ha_appointments_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Appointments', 'hospital-appointments'); ?></h1>
        
        <div class="ha-filters">
            <form method="get">
                <input type="hidden" name="page" value="hospital-appointments">
                
                <select name="doctor">
                    <option value=""><?php _e('All Doctors', 'hospital-appointments'); ?></option>
                    <?php
                    global $wpdb;
                    $doctors = $wpdb->get_results("SELECT id, name FROM {$wpdb->prefix}ha_doctors ORDER BY name ASC");
                    foreach ($doctors as $doctor) {
                        $selected = isset($_GET['doctor']) && $_GET['doctor'] == $doctor->id ? 'selected' : '';
                        echo '<option value="' . $doctor->id . '" ' . $selected . '>' . esc_html($doctor->name) . '</option>';
                    }
                    ?>
                </select>
                
                <input type="date" name="date" value="<?php echo isset($_GET['date']) ? esc_attr($_GET['date']) : ''; ?>">
                
                <input type="text" name="search" placeholder="<?php _e('Search patient name or email...', 'hospital-appointments'); ?>"
                       value="<?php echo isset($_GET['search']) ? esc_attr($_GET['search']) : ''; ?>">
                
                <input type="submit" class="button" value="<?php _e('Filter', 'hospital-appointments'); ?>">
            </form>
        </div>
        
        <?php
        // Build query
        $where = array('1=1');
        $params = array();
        
        if (!empty($_GET['doctor'])) {
            $where[] = 'a.doctor_id = %d';
            $params[] = intval($_GET['doctor']);
        }
        
        if (!empty($_GET['date'])) {
            $where[] = 'DATE(a.appointment_date) = %s';
            $params[] = sanitize_text_field($_GET['date']);
        }
        
        if (!empty($_GET['search'])) {
            $where[] = '(a.patient_name LIKE %s OR a.patient_email LIKE %s)';
            $search_term = '%' . $wpdb->esc_like(sanitize_text_field($_GET['search'])) . '%';
            $params[] = $search_term;
            $params[] = $search_term;
        }
        
        $query = $wpdb->prepare(
            "SELECT a.*, d.name as doctor_name 
             FROM {$wpdb->prefix}ha_appointments a 
             LEFT JOIN {$wpdb->prefix}ha_doctors d ON a.doctor_id = d.id 
             WHERE " . implode(' AND ', $where) . " 
             ORDER BY a.appointment_date DESC, a.appointment_time DESC",
            $params
        );
        
        $appointments = $wpdb->get_results($query);
        ?>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('Patient Name', 'hospital-appointments'); ?></th>
                    <th><?php _e('Email', 'hospital-appointments'); ?></th>
                    <th><?php _e('Doctor', 'hospital-appointments'); ?></th>
                    <th><?php _e('Date & Time', 'hospital-appointments'); ?></th>
                    <th><?php _e('Status', 'hospital-appointments'); ?></th>
                   
                </tr>
            </thead>
            <tbody>
                <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?php echo esc_html($appointment->patient_name); ?></td>
                        <td><?php echo esc_html($appointment->patient_email); ?></td>
                        <td><?php echo esc_html($appointment->doctor_name); ?></td>
                        <td><?php 
                            echo date_i18n(get_option('date_format'), strtotime($appointment->appointment_date)) . ' ';
                            echo date_i18n(get_option('time_format'), strtotime($appointment->appointment_time));
                        ?></td>
                        <td>
                            <select class="ha-status-select" data-id="<?php echo $appointment->id; ?>">
                                <?php
                                $statuses = array('pending', 'confirmed', 'completed', 'cancelled');
                                foreach ($statuses as $status) {
                                    $selected = $appointment->status === $status ? 'selected' : '';
                                    echo '<option value="' . $status . '" ' . $selected . '>' . ucfirst($status) . '</option>';
                                }
                                ?>
                            </select>
                        </td>
                 
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// AJAX handlers for appointment operations
add_action('wp_ajax_ha_update_appointment_status', 'ha_ajax_update_appointment_status');
add_action('wp_ajax_ha_delete_appointment', 'ha_ajax_delete_appointment');

function ha_ajax_update_appointment_status() {
    check_ajax_referer('ha_appointment_actions', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions', 'hospital-appointments'));
    }
    
    global $wpdb;
    $appointment_id = isset($_POST['appointment_id']) ? intval($_POST['appointment_id']) : 0;
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
    
    if ($appointment_id && $status) {
        $wpdb->update(
            "{$wpdb->prefix}ha_appointments",
            array('status' => $status),
            array('id' => $appointment_id)
        );
        
        // Send email notification about status change
        ha_send_status_update_email($appointment_id, $status);
    }
    
    wp_send_json_success();
}

function ha_ajax_delete_appointment() {
    check_ajax_referer('ha_appointment_actions', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions', 'hospital-appointments'));
    }
    
    global $wpdb;
    $appointment_id = isset($_POST['appointment_id']) ? intval($_POST['appointment_id']) : 0;
    
    if ($appointment_id) {
        $wpdb->delete(
            "{$wpdb->prefix}ha_appointments",
            array('id' => $appointment_id)
        );
    }
    
    wp_send_json_success();
}