<?php
if (!defined('ABSPATH')) {
    exit;
}

class HA_Email_Notifications {
    
    public static function send_confirmation_email($appointment_id) {
        global $wpdb;
        
        $appointment = $wpdb->get_row($wpdb->prepare(
            "SELECT a.*, d.name as doctor_name, d.specialty 
             FROM {$wpdb->prefix}ha_appointments a 
             LEFT JOIN {$wpdb->prefix}ha_doctors d ON a.doctor_id = d.id 
             WHERE a.id = %d",
            $appointment_id
        ));
        
        if (!$appointment) {
            return false;
        }
        
        $to = $appointment->patient_email;
        $subject = sprintf(__('Appointment Confirmation - %s', 'hospital-appointments'), get_bloginfo('name'));
        
        $message = sprintf(
            __('Dear %s,

Thank you for booking an appointment with us. Here are your appointment details:

Doctor: %s (%s)
Date: %s
Time: %s

Status: %s

Please arrive 10 minutes before your scheduled appointment time.

If you need to cancel or reschedule, please contact us as soon as possible.

Best regards,
%s', 'hospital-appointments'),
            $appointment->patient_name,
            $appointment->doctor_name,
            $appointment->specialty,
            date_i18n(get_option('date_format'), strtotime($appointment->appointment_date)),
            date_i18n(get_option('time_format'), strtotime($appointment->appointment_time)),
            ucfirst($appointment->status),
            get_bloginfo('name')
        );
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        return wp_mail($to, $subject, nl2br($message), $headers);
    }
    
    public static function send_status_update_email($appointment_id, $new_status) {
        global $wpdb;
        
        $appointment = $wpdb->get_row($wpdb->prepare(
            "SELECT a.*, d.name as doctor_name 
             FROM {$wpdb->prefix}ha_appointments a 
             LEFT JOIN {$wpdb->prefix}ha_doctors d ON a.doctor_id = d.id 
             WHERE a.id = %d",
            $appointment_id
        ));
        
        if (!$appointment) {
            return false;
        }
        
        $to = $appointment->patient_email;
        $subject = sprintf(__('Appointment Status Update - %s', 'hospital-appointments'), get_bloginfo('name'));
        
        $message = sprintf(
            __('Dear %s,

Your appointment status has been updated:

Doctor: %s
Date: %s
Time: %s
New Status: %s

If you have any questions, please contact us.

Best regards,
%s', 'hospital-appointments'),
            $appointment->patient_name,
            $appointment->doctor_name,
            date_i18n(get_option('date_format'), strtotime($appointment->appointment_date)),
            date_i18n(get_option('time_format'), strtotime($appointment->appointment_time)),
            ucfirst($new_status),
            get_bloginfo('name')
        );
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        return wp_mail($to, $subject, nl2br($message), $headers);
    }
}

// Helper functions
function ha_send_confirmation_email($appointment_id) {
    return HA_Email_Notifications::send_confirmation_email($appointment_id);
}

function ha_send_status_update_email($appointment_id, $new_status) {
    return HA_Email_Notifications::send_status_update_email($appointment_id, $new_status);
}